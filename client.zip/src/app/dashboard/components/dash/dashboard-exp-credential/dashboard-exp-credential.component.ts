import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-exp-credential',
  standalone: true,
  imports: [],
  templateUrl: './dashboard-exp-credential.component.html',
  styleUrl: './dashboard-exp-credential.component.css'
})
export class DashboardExpCredentialComponent {

}
