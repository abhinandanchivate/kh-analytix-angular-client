import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-edu-credential-row',
  standalone: true,
  imports: [],
  templateUrl: './dashboard-edu-credential-row.component.html',
  styleUrl: './dashboard-edu-credential-row.component.css'
})
export class DashboardEduCredentialRowComponent {

}
