import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-action',
  standalone: true,
  imports: [],
  templateUrl: './dashboard-action.component.html',
  styleUrl: './dashboard-action.component.css'
})
export class DashboardActionComponent {

}
